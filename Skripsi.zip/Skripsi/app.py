# import pandas as pd
# from flask import Flask, render_template, request
# import csv
# import io
# from transformers import pipeline

# app = Flask(__name__)

# # Load sentiment analysis model
# sentiment_analysis = pipeline("sentiment-analysis", model="Bagas54/mona-roberta-base-sentiment")

# # Read aspect keywords from Excel file
# aspect_keywords_df = pd.read_excel("keyword-hotel-english.xlsx")

# # Function to map sentiment labels to custom labels
# def map_sentiment_label(label):
#     if label == "LABEL_0":
#         return "Negatif"
#     elif label == "LABEL_1":
#         return "Positif"
#     elif label == "LABEL_2":
#         return "Netral"
#     else:
#         return "Unknown"

# # Function to analyze sentiment for a given text
# def analyze_sentiment(text):
#     result = sentiment_analysis(text)
#     sentiment_label = map_sentiment_label(result[0]['label'])
#     score = result[0]['score']
#     return sentiment_label, score

# # Function to identify aspects in a given text
# def identify_aspects(text):
#     identified_aspects = []
#     for col in aspect_keywords_df.columns:
#         for keyword in aspect_keywords_df[col]:
#             if str(keyword).lower() in text.lower():
#                 identified_aspects.append(col)
#                 break
#     return identified_aspects

# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/text_input')
# def text_input():
#     return render_template('text_input.html')

# @app.route('/upload_csv')
# def upload_csv():
#     return render_template('upload_csv.html')

# @app.route('/analyze_text', methods=['POST'])
# def analyze_text():
#     if request.method == 'POST':
#         text = request.form['text']
#         identified_aspects = identify_aspects(text)
#         aspect_results = []
#         for aspect in identified_aspects:
#             sentiment, score = analyze_sentiment(text)
#             aspect_results.append({'aspect': aspect, 'sentiment': sentiment, 'score': score})
#         return render_template('result.html', text=text, aspects=aspect_results)
#     return render_template('text_input.html')

# @app.route('/analyze_csv', methods=['POST'])
# def analyze_csv():
#     if request.method == 'POST':
#         csv_file = request.files['file']
#         texts = []
#         results = []
#         if csv_file.filename != '':
#             stream = io.StringIO(csv_file.stream.read().decode("UTF8"), newline=None)
#             csv_reader = csv.reader(stream)
#             for row in csv_reader:
#                 texts.append(row[0])  # Assuming the text is in the first column
#             for text in texts:
#                 identified_aspects = identify_aspects(text)
#                 aspect_results = []
#                 for aspect in identified_aspects:
#                     sentiment, score = analyze_sentiment(text)
#                     aspect_results.append({'aspect': aspect, 'sentiment': sentiment, 'score': score})
#                 results.append({'text': text, 'aspects': aspect_results})
#             return render_template('result.html', results=results)
#     return render_template('upload_csv.html')

# if __name__ == '__main__':
#     app.run(debug=True)

# from flask_login import login_required

# @app.route('/text_input')
# @login_required
# def text_input():
#     return render_template('text_input.html')

# @app.route('/upload_csv')
# @login_required
# def upload_csv():
#     return render_template('upload_csv.html')

