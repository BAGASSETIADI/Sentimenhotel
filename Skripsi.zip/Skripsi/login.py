from flask import Flask, render_template, request, redirect, session
from flask_mysqldb import MySQL
import pandas as pd
import csv
import io
from transformers import pipeline

# Load sentiment analysis model
sentiment_analysis = pipeline("sentiment-analysis", model="Bagas54/mona-roberta-base-sentiment")

# Read aspect keywords from Excel file
aspect_keywords_df = pd.read_excel("keyword-hotel-english.xlsx")

# Function to map sentiment labels to custom labels
def map_sentiment_label(label):
    if label == "LABEL_0":
        return "Negatif"
    elif label == "LABEL_1":
        return "Positif"
    elif label == "LABEL_2":
        return "Netral"
    else:
        return "Unknown"

# Function to analyze sentiment for a given text
def analyze_sentiment(text):
    result = sentiment_analysis(text)
    sentiment_label = map_sentiment_label(result[0]['label'])
    score = result[0]['score']
    return sentiment_label, score

# Function to identify aspects in a given text
def identify_aspects(text):
    identified_aspects = []
    for col in aspect_keywords_df.columns:
        for keyword in aspect_keywords_df[col]:
            if str(keyword).lower() in text.lower():
                identified_aspects.append(col)
                break
    return identified_aspects

app = Flask(__name__, template_folder="templates")
app.secret_key = 'your_secret_key'  # Keep this secure in production

# Database configuration
app.config['MYSQL_HOST'] = 'localhost'  # Change this to your database host
app.config['MYSQL_USER'] = 'root'   # Change this to your database user
app.config['MYSQL_PASSWORD'] = ''  # Change this to your database password
app.config['MYSQL_DB'] = 'skripsi'  # Change this to your database name
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'  # Return rows as dictionaries

mysql = MySQL(app)

@app.route('/')
def home():
    if 'username' in session:
        return redirect('/home')
    else:
        return redirect('/login')
    
@app.route('/text_input')
def text_input():
    return render_template('text_input.html')
@app.route('/upload_csv')
def upload_csv():
    return render_template('upload_csv.html')
@app.route('/analyze_text', methods=['POST'])
def analyze_text():
    if request.method == 'POST':
        text = request.form['text']
        identified_aspects = identify_aspects(text)
        aspect_results = []
        for aspect in identified_aspects:
            sentiment, score = analyze_sentiment(text)
            aspect_results.append({'aspect': aspect, 'sentiment': sentiment, 'score': score})
        return render_template('result.html', text=text, aspects=aspect_results)
    return render_template('text_input.html')

@app.route('/analyze_csv', methods=['POST'])
def analyze_csv():
    if request.method == 'POST':
        csv_file = request.files['file']
        texts = []
        results = []
        if csv_file.filename != '':
            stream = io.StringIO(csv_file.stream.read().decode("UTF8"), newline=None)
            csv_reader = csv.reader(stream)
            for row in csv_reader:
                texts.append(row[0])  # Assuming the text is in the first column
            for text in texts:
                identified_aspects = identify_aspects(text)
                aspect_results = []
                for aspect in identified_aspects:
                    sentiment, score = analyze_sentiment(text)
                    aspect_results.append({'aspect': aspect, 'sentiment': sentiment, 'score': score})
                results.append({'text': text, 'aspects': aspect_results})
            return render_template('result.html', results=results)
    return render_template('upload_csv.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()
        if user and user['password'] == password:
            session['username'] = username
            return redirect('/')
        else :
            return 'Invalid username/password combination'
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        id = request.form['id']
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()

        if user:
            return 'Username sudah digunakan, coba yang lain'
        else:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO users (id, username, password) VALUES (%s, %s, %s)", (id, username, password))
            mysql.connection.commit()
            cur.close()

            return redirect('/login')

    return render_template('register.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')

@app.route('/home')
def protected_home():
    if 'username' in session:
        return render_template('index.html')
    else:
        return redirect('/login')

if __name__ == '__main__':
    app.run(debug=True)